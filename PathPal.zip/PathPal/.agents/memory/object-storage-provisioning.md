---
name: Managed object storage provisioning
description: A transient provisioning failure can precede successful default App Storage setup.
---

Default App Storage provisioning returned a generic internal error on the first attempt, while a later idempotent attempt succeeded.

**Why:** Report-photo requests returned a storage-related 503 even though report sessions and lists were healthy; treating the provisioning error as permanent would have left photo support broken.

**How to apply:** Keep API connectivity and object-storage readiness as separate checks. If setup returns a generic provisioning failure, retry the idempotent setup once before changing application code.